interface ISlider {
  title: string;
  desc: string;
  image: string;
}

export class SliderClass {
  constructor(public title: string, public desc: string, public image: string) {
  }
}

export let Sliders:SliderClass[] = [
  new SliderClass("", "", "assets/slider1.png"),
  new SliderClass("", "", "assets/sliderImg/Slider1.jpg"),
  new SliderClass("The Web as I envisaged it, we have not seen it yet", "third description", "assets/sliderImg/Slider1.jpg"),
  new SliderClass("Once a new technology rolls over you, if you're not part of the steamroller, you're part of the road", "forth description", "assets/sliderImg/Slider1.jpg"),
  new SliderClass("It's not a faith in technology. It's faith in people", "fifth description", "assets/sliderImg/Slider1.jpg"),
];
